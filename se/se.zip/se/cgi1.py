#!/usr/bin/python

import cgi
import cgitb;cgitb.enable()

print "Content-type: text/html\n\n"
print "<html>hi</html>"

